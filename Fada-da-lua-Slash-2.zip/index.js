const c = require('colors');


const express = require('express'); 

const app = express(); 
app.get("/", (request, response) => { 
  const ping = new Date(); 
  ping.setHours(ping.getHours() - 3); 
console.log(c.green(`${ping.getUTCHours()}:${ping.getUTCMinutes()}:${ping.getUTCSeconds()} => Website ping recebido.`)); 
  response.sendStatus(200); 
});
app.listen(process.env.PORT);


const { Snake } = require('discord-gamecord');
const moment = require("moment");
require("moment-duration-format");
const os = require('os');
const si = require('systeminformation');
const akinator = require("discord.js-akinator");

const Discord = require("discord.js"); 
const client = new Discord.Client({intents: 32767});
const config = require("./config.json"); 

client.login(process.env.Token); 

client.once('ready', async () => {


  

  console.log(c.red("-----------------------------------------"))
    console.log(c.blue("✅ - Logado em "+client.user.username+" com sucesso!"))
  console.log(c.red("-----------------------------------------"))

})
  
    


module.exports = client;
client.commands = new Discord.Collection();
client.slashCommands = new Discord.Collection();
client.config = require("./config.json");
require("./handler")(client);
const { glob } = require("glob");
const { promisify } = require("util");

const globPromise = promisify(glob);

client.on("interactionCreate", async (interaction) => {

    if (!interaction.guild) return;
  
    if (interaction.isCommand()) {

        const cmd = client.slashCommands.get(interaction.commandName);

        if (!cmd)
            return;

        const args = [];

        for (let option of interaction.options.data) {

            if (option.type === "SUB_COMMAND") {
                if (option.name) args.push(option.name);
                option.options?.forEach((x) => {
                    if (x.value) args.push(x.value);
                });
            } else if (option.value) args.push(option.value);
        }

        cmd.run(client, interaction, args);
    }

    if (interaction.isContextMenu()) {
        await interaction.deferReply({ ephemeral: false });
        const command = client.slashCommands.get(interaction.commandName);
        if (command) command.run(client, interaction);
        
    }
});


process.on('multipleResolves', (type, reason, promise) => {
    console.log(c.red(`🚫 Erro Detectado\n\n` + type, promise, reason))
});
process.on('unhandRejection', (reason, promise) => {
    console.log(c.red(`🚫 Erro Detectado:\n\n` + reason, promise))
});
process.on('uncaughtException', (error, origin) => {
    console.log(c.red(`🚫 Erro Detectado:\n\n` + error, origin))
});
process.on('uncaughtExceptionMonitor', (error, origin) => {
    console.log(c.red(`🚫 Erro Detectado:\n\n` + error, origin))
});



const info = {
 mongo: process.env.mongo, 
 author: '</ThallesKraft>', 
 sobre: {
  nome: 'Conectar',
  description: 'ele conecta a database mongo'
   }
}


//-----------------TICJE-SITEMA---------
client.on("interactionCreate", (interaction) => {
    if (interaction.isButton()) {
        if (interaction.customId === "t") {
            if (interaction.guild.channels.cache.find(c => c.name === `🎟️-${interaction.user.tag}`)) {
                let c = interaction.guild.channels.cache.find(c => c.name === `🎟️-${interaction.user.tag}`);
                interaction.reply({ content: `Você já possui um ticket aberto em ${c}.`, ephemeral: true })
            } else {
                interaction.guild.channels.create(`🎟️-${interaction.user.tag}`, {
                    type: "GUILD_TEXT",
                    //parent: "",
                    permissionOverwrites: [
                        {
                            id: interaction.guild.id,
                            deny: ["VIEW_CHANNEL"]
                        },
                        {
                            id: interaction.user.id,
                            allow: ["VIEW_CHANNEL", "SEND_MESSAGES", "ATTACH_FILES", "ADD_REACTIONS"]
                        }
                    ]
                }).then(c => {

                    interaction.reply({ content: `Olá, seu ticket foi aberto em ${c}.`, ephemeral: true })

                    let embed = new Discord.MessageEmbed()
                    .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                    .setDescription(`> <:lapis:957705280467132536> **Ticket aberto por:**\n${interaction.user}\n\n> <:new_member:956582582366138431> **Descrição:**\nOlá... ${interaction.user.tag} Bem por favor especifique o motivo para ter aberto o ticket ${c}, que seja bem claro! por favor`)
                    .setFooter("Aperte o botão abaixo para fechar o tickt!")
                    .setTimestamp(new Date())
                    .setColor('ffcdbd')

                    let botao = new Discord.MessageActionRow()
                    .addComponents(
                        new Discord.MessageButton()
                        .setCustomId("tf")
                        .setEmoji("<:chave:957273691576733786>")
                        .setStyle("SECONDARY")
                    );

                    c.send({ embeds: [embed], components: [botao] }).then(msg => msg.pin())
                })
            }
        } else if (interaction.customId === "tf") {
            interaction.reply(`este ticket será fechado em 5 segundos...`).then(() => {
                setTimeout(() => {
                    interaction.channel.delete();
                }, 5000)
            })
        }
    }
});

//----------------ENTRADA SETUP--------------

const db = require('quick.db');
              //------AFK
client.on("messageCreate", (message) => {

    if (message.author.bot) return;

    let pessoa = db.get(`verificando_afk_${message.author.id}`);

    if (message.author.id === pessoa) {
        message.reply(`Ola ${message.author}, Seu modo afk foi desativado 😉\;)`).then(msg => {
            db.delete(`afk_${message.author.id}`);
            db.delete(`motivo_afk_${message.author.id}`)
            db.delete(`verificando_afk_${message.author.id}`)
        })
    } else {

    let user_afk = message.mentions.members.first();

    if (!user_afk) return;

    let motivo = db.get(`motivo_afk_${user_afk.id}`);
    let afk = db.get(`afk_${user_afk.id}`);

    if (afk === true) return message.reply(`${message.author}, \`${user_afk.user.username} está em AFK motivo:\` ${motivo}`);

    } 
    
})




  //---------LOGS----------
