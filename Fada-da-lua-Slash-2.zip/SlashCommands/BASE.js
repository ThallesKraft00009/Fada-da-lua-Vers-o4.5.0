const Discord = require('discord.js');

module.exports =  {
    name: "",
    description: "『』",
    type: "CHAT_INPUT",
    options: [
        {
            name: "",
            type: "STRING",
            description: "",
            required: true
            
        }
    
    ],
    
    run: async (client, interaction, args) => {

    }
}