const ms = require("ms")

module.exports =  {
    name: "castigar",
    description: "『🔨』Dê o castigo para um membro.",
    type: "CHAT_INPUT",
    options: [
        {
            name: "membro",
            type: "USER",
            description: "Mencione um usuário para ser punido.",
            required: true
            
        },
        {
            name: "tempo",
            type: "STRING",
            description: "Coloque o tempo de duração do castigo.",
            required: true
            
        },
        {
            name: "motivo",
            type: "STRING",
            description: "Coloque o motivo do castigo.",
            required: true
            
        }
    
    ],
    
    run: async (client, interaction, args) => {

        if (!interaction.member.permissions.has("TIMEOUT_MEMBERS")) {
            interaction.reply({ content: `Você não possui permissão de \`TIMEOUT_MEMBERS\` para utilizar este comando.` })
        } else {

        let usuario = interaction.options.getUser("membro");

        let membro = interaction.guild.members.cache.get(usuario.id);
        let tempo = interaction.options.getString("tempo");
        let motivo = interaction.options.getString("motivo");

        let duracao = ms(tempo);

        if (!membro) {
            interaction.reply({ content: `O usuário não está no servidor.` })
        } else if (!duracao) {
            interaction.reply({ content: `Insira um tempo válido.` })
        } else {
            membro.timeout(duracao, motivo).then( () => {
                interaction.reply({ content: `O membro \`${membro.user.tag}\` foi punido por \`${tempo}\`, pelo motivo \`${motivo}\`.`, ephemeral: false })
            })
        }

    }

    }
}