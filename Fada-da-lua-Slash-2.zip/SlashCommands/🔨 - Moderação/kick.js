const Discord = require('discord.js')

module.exports = {
    name: 'kick',
    description: '『🔨』Expulsa um usuário de um servidor.',
    options: [{
        name: 'usuario',
        type: 'USER',
        description: 'Mencione um usuário.',
        required: true,
    }],
    run: async (client, interaction, options) => {
        
        const user = interaction.options.getUser('usuario')
        
        if (!interaction.member.permissions.has("KICK_MEMBERS")) return          interaction.reply({ content: `<:ShirakameError:954418378716631040> | Você não possui permissão de \`Expulsar Membros\`para utilizar este comando.`, ephemeral: true });
        
        if (!user) return interaction.reply(`<:ShirakameError:954418378716631040> | Algo de errado não esta certo, não encontrei este usuário no servidor.`);


        
interaction.guild.members.kick(user);

        interaction.reply({ content: `<:ShirakameCheck:954415421203816469> | ${user} foi expulso com sucesso! Quem mandou quebrar as regras?!`});
        
        

    }
}