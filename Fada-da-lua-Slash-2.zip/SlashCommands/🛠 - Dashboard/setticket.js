
const Discord = require("discord.js");



module.exports = {
  name: 'setticket',
  description: '『🛠』Setar local do sistema de ticket',
  type: 'CHAT_INPUT',
  options: [
    {
      name: 'canal',
      description: 'Canal que deseja setar o ticket',
      type: 'CHANNEL',
      required: true,
      },
    {
            name: "titulo",
            type: "STRING",
            description: "the title of this ticket",
            required: true,       
    },
    {
            name: "descrição",
            type: "STRING",
            description: "the description of ticket", 
            required: true,       
        },
        {
            name: "imagem",
            type: "STRING",
            description: "the image of this ticket",
            required: false       
        }],
  run: async (client, interaction, args) => {
    if (!interaction.member.permissions.has("MANAGE_GUILD")) {
      interaction.reply(`Ops... Você não possui permissão \`MANAGE_GUILD\` para utilizar este comando`)
    } else {
let titulo = interaction.options.getString("titulo");
        if (titulo == null) titulo = '';
        let descrição = interaction.options.getString("descrição");
      let imagem = interaction.options.getString("imagem");
        if (imagem == null) imagem = '';
      let canal = interaction.options.getChannel('canal') || interaction.channel;
      if (!canal.isText()) {
        return interaction.reply({ content: '❌ Selecione um canal de texto', ephemeral: true });
      }
      let embed = new Discord.MessageEmbed()
        .setColor("RANDOM")
        .setImage(imagem)
        .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
        .setFooter("Aperte o botão abaixo para abrir o ticket!")
        .setTimestamp(new Date())
        .setTitle(titulo)
        .setDescription(descrição);

      let botao = new Discord.MessageActionRow()
        .addComponents(
          new Discord.MessageButton()
          .setCustomId("t")
          .setEmoji("<<:chave:957273691576733786>957273691576733786>")
          .setStyle("SECONDARY")
        );
      interaction.reply({ content: `Ticket enviado com sucesso para <#${canal.id}>` })
      canal.send({ embeds: [embed], components: [botao] }).then();
    }



  }
}



