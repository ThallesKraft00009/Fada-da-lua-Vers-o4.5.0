const db = require("quick.db")

module.exports =  {
    name: "setsugestao",
    description: "『🛠』Configure o canal de sugestões no servidor.",
    type: "CHAT_INPUT",
    options: [
        {
            name: "canal",
            type: "CHANNEL",
            description: "Selecione um canal de texto.",
            required: true
            
        }
    
    ],
    
    run: async (client, interaction, args) => {

        if (!interaction.member.permissions.has("MANAGE_GUILD")) {
            interaction.reply({ content: `Você não possui permissão para utilizar este comando.`, ephemeral: true })
        } else {
            let canal = interaction.options.getChannel("canal");
            if (canal.type !== "GUILD_TEXT") {
                interaction.reply({ content: `O canal ${canal} não é um canal de texto.`, ephemeral: true })
            } else {
                interaction.reply(`O canal de texto ${canal} foi configurado com sucesso.`)
                db.set(`canal_seguestoes_${interaction.guild.id}`, canal.id)
            }
        }

    }
}