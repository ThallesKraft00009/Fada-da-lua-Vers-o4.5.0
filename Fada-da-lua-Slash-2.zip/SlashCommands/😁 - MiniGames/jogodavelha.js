
const { TicTacToe } = require('discord-gamecord')
const {
  Client,
  Message,
  MessageActionRow,
  MessageButton,
  MessageEmbed,
  CommandInteraction,
} = require("discord.js");

const { Connect4 } = require('discord-gamecord')

module.exports =  {
    name: "jogodavelha",
    description: "『😁』Jogue o jogo da velha no discord",
    type: "CHAT_INPUT",
    options: [
       {
        name: "user",
        type: "USER",
        description: "seleciona o membro que deseja competir.",
        required: true
        
        }
      ],
    
    run: async (client, interaction, args) => {

      let member = interaction.options.getUser("user");

new TicTacToe({
  message: interaction,
  slash_command: true,
  opponent: member,
  embed: {
    title: 'JOGO DA VELHA',
    overTitle: 'FIM DE JOGO',
    color: '#5865F2',
  },
  oEmoji: '🔵',
  xEmoji: '❌',
  blankEmoji: '➖',
  oColor: 'PRIMARY',
  xColor: 'DANGER',
  waitMessage: 'Aguardando pelo oponente.',
  turnMessage: '{emoji} **{player}** é sua vez',
  askMessage: '{opponent}, {challenger} desafiou você para um jogo a velha',
  cancelMessage: '{opponent} Jogo da velha é bom, por que recusou? \:(',
  timeEndMessage: 'Como o oponente não respondeu, larguei o jogo!',
  drawMessage: 'Foi um empate!',
  winMessage: '**{winner}** ganhou o jogo.',
  gameEndMessage: 'O jogo ficou inacabado :(',
}).startGame();
    
    }
}
