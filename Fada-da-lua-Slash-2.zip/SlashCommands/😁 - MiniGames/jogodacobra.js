const { Snake } = require('discord-gamecord');
const Discord = require('discord.js');

module.exports =  {
    name: "jogodacobra",
    description: "『😁』Jogue o jogo na cobra no discord",
    type: "CHAT_INPUT",
    
    
    run: async (client, interaction, args) => {

new Snake({
  message: interaction,
  slash_command: true,
  embed: {
    title: 'Jogo da Cobra',
    color: 'GREEN',
    OverTitle: 'Você perdeu o jogo',
  },
  snake: { head: '🟢', body: '🟩', tail: '🟢', over: '💀' },
  emojis: {
    board: '⬛', 
    food: '🍎',
    up: '⬆️', 
    right: '➡️',
    down: '⬇️',
    left: '⬅️',
  },
  foods: ['🍎', '🍇', '🍊', '🍒', '🥕', '🥦'],
  stopButton: 'Parar',
  othersMessage: 'Você não pode usar os botões de outra pessoa!',
}).startGame();
    }
};