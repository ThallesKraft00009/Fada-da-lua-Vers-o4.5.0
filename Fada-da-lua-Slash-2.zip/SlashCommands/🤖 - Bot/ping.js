const Discord = require('discord.js');

module.exports =  {
    name: "ping",
    description: "『🤖』Mostrar meu ping atual",
    type: "CHAT_INPUT",
    
    
    run: async (client, interaction, args) => {

let ping = client.ws.ping;

      let embed = new Discord.MessageEmbed()
      .setTitle(`🏓 Pong!`)
      .setDescription(`Minha latência é \`${ping}ms\`!
No caso de ping alto, avise imediatamente para <@882913524291088384>!`)
      .setColor("RANDOM")
      
interaction.reply({embeds: [embed]}) 

    }
}