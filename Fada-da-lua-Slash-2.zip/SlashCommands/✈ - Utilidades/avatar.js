
const Discord = require("discord.js");

module.exports = {
  name: "avatar",
  description: "『🗣』Pegue o Avatar de Alguém",
  options: [
    {
      name: "user",
      description: "qual é o user que você quer pegar o avatar?",
      type: "USER",
      required: false
    }
  ],

  run: async (client, interaction, args) => {

    let men = interaction.options.getUser("user") || interaction.user

    let embed = new Discord.MessageEmbed()
    .setTitle(`*\`[ ${men.tag} ]\`*`)
    .setImage(men.displayAvatarURL({ dynamic: true, size: 1024 }))
    .setFooter({ text: `Comando Executado Por ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() })
    .setColor("RANDOM")
    .setTimestamp()

    const button = new Discord.MessageActionRow().addComponents(
            new Discord.MessageButton()

                .setStyle("LINK")
                .setLabel(".PNG")
                .setURL(`${men.avatarURL({ format: "png", size: 1024 })}`),
            new Discord.MessageButton()

                .setStyle("LINK")
                .setLabel(".GIF")
                .setURL(`${men.avatarURL({ dynamic: true, size: 1024 })}`),
            new Discord.MessageButton()

                .setStyle("LINK")
                .setLabel(".JPG")
                .setURL(`${men.avatarURL({ format: "jpg", size: 1024 })}`)
        );

    interaction.reply({ embeds: [embed], components: [button] })
  }
} 
