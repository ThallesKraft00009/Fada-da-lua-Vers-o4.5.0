
const Discord = require('discord.js')

module.exports = {
name: "bug",
description: "『💵』Reportar um bug do mini world",
type: 'CHAT_INPUT',
options: [
        {
         name: "uid",
         description: "Seu uid no jogo.",
         type: "STRING",
         required: true,
        },
  {
          name: "rede",
            type: "STRING",
            description: "Rede com fio ou sem fio?",
            required: true,       
    },

  {
          name: "dispositivo",
            type: "STRING",
            description: "O dispositivo que você usa e o nome",
            required: true,       
    },
  
  {
          name: "bug",
            type: "STRING",
            description: "erro ocoriddo",
            required: true,       
    },{
    
          name: "imagem",
            type: "STRING",
            description: "url de imagem do bug",
            required: false,       
  }
],
run: async (client, interaction, args) => {

let uid = interaction.options.getString("uid");

  let rede = interaction.options.getString("rede");

  
  
let disp = interaction.options.getString("dispositivo");

  let bug = interaction.options.getString("bug");

  
  let image = interaction.options.getString("imagem");
  if (image == null) image = '';
  

let canal = client.channels.cache.get("751547295371100300")
  
const embed = new Discord.MessageEmbed()
  .setImage(image)

.setFooter({ text: interaction.user.username, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
            .setTimestamp(new Date())
.setColor("RANDOM")
.setTitle(`📣 Novo bug reportado 🚫`)
.addFields(
{
name: "Uid do usuário", 
value: `\n\`\`\` ${uid}\`\`\``,
inline: true
}, 
  {
name: "Rede do usuário", 
value: `\n\`\`\` ${rede}\`\`\``,
inline: true
}, 
    {
name: "Informacoes de dispositivo", 
value: `\n\`\`\` ${disp}\`\`\``,
inline: true
}, 
    {
name: "Descrição do problema", 
value: `\n\`\`\` ${bug}\`\`\``,
inline: true
}, 
{
name: "Nome do usuário discord",
value: `\`${interaction.member.user.tag}\``,
inline: false
},{
name: "Id do discord", 
value: `\n\`\`\`${interaction.member.user.id}\`\`\``,
inline: false
})
const embed30 = new Discord.MessageEmbed()
.setDescription(`🚫 | ${interaction.member.user.username} Sua descrição foi enviado com sucesso`)
.setColor("RANDOM")
interaction.reply({embeds: [embed30],})

canal.send({embeds: [embed]})
}
} 
