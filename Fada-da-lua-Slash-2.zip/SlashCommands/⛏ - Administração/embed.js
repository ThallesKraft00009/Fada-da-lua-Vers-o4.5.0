
const discord = require('discord.js')
module.exports =  {
    name: "embed",
    description: "『⛏』Criar uma embed!",
    type: "CHAT_INPUT",
    options: [
        
        {
            name: "descrição",
            type: "STRING",
            description: "descrição da embed", 
            required: true,       
        },
        {
            name: "titulo",
            type: "STRING",
            description: "titulo da embed",
            required: false,
            
        },
        {
            name: "cor",
            type: "STRING",
            description: "envie uma cor em ingles exemplo BLUE",
            required: false,
        },
        {
            name: "imagem",
            type: "STRING",
            description: "coloque uma URL de imagem",
            required: false,
        },    {
            name: "thumbnail",
            type: "STRING",
            description: "coloque uma URL de imagem",
            required: false,
        
        }
        
        
        
        
        
    
    ],
    
    run: async (client, interaction, args) => {
     if (!interaction.member.permissions.has("MANAGE_GUILD")) {
            interaction.reply({ content: `Você não tem permissão de \`Gerenciar servidor\` para utilizar esse comando.`, ephemeral: true })
        } else {
        let titulo = interaction.options.getString("titulo");
        if (titulo == null) titulo = '';
       let thum = interaction.options.getString("thumbnail");
        if (thum == null) thum = '';


        let descrição = interaction.options.getString("descrição");
        let cor = interaction.options.getString("cor");
        if (cor == null) cor = 'RANDOM';
        let img = interaction.options.getString("imagem");
        if (img == null) img = '';

        const embed = new discord.MessageEmbed()
        .setTitle(`${titulo}`)
        .setDescription(`${descrição}`)
        .setColor(`${cor}`)
        .setImage(`${img}`)
       .setThumbnail(`${thum}`)

        interaction.reply({content: `A embed foi criada com sucesso!`, ephemeral: true})
        interaction.channel.send({ embeds: [embed]})
    }
}
            }
