const Discord = require('discord.js');

module.exports =  {
    name: "say",
    description: "『⛏』Faça eu falar",
    type: "CHAT_INPUT",
    options: [
        {
            name: "mensagem",
            type: "STRING",
            description: "Fale a message para eu falar.",
            required: false
            
        }
    
    ],
    
    run: async (client, interaction, args) => {

if (!interaction.member.permissions.has("MANAGE_MESSAGES")) {
            interaction.reply({ content: `Você não tem permissão de \`Gerenciar Messages\` para utilizar esse comando.`, ephemeral: true })
        } else {
        let message = interaction.options.getString("mensagem");
        if (message == null) message = `${interaction.user} E tão bobaum que nem especificou a message para eu enviar 🤭`;


interaction.reply(message)
          }
    }
}