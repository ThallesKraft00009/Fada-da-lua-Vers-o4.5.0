const Discord = require('discord.js')
module.exports = {
    name: 'tapa',
    description: '『🎉』Dê um tapa em uma pessoa.',
    type: 'CHAT_INPUT',
    options: [
        {
            name: 'membro',
            description: 'Mencione um membro.',
            type: "USER",
            required: true,
        }
    ],
    run: async (client, interaction, args) => {

        let user = interaction.options.getUser('membro')

        var lista1 = [
            'https://imgur.com/HYJHoG7.gif',
            'https://imgur.com/9GxTsgl.gif',
            'https://imgur.com/mT4VjD6.gif',
            'https://imgur.com/mT4VjD6.gif',
            'https://imgur.com/w66ZqGR.gif'
        ];

        var lista2 = [
            'https://imgur.com/oSoudVd.gif',
            'https://imgur.com/T9w8eFV.gif',
            'https://imgur.com/nuDmQu5.gif',
            'https://imgur.com/wlLCjRo.gif',
            'https://imgur.com/sVeYncu.gif'
        ];

        var random1 = lista1[Math.floor(Math.random() * lista1.length)];
        var random2 = lista2[Math.floor(Math.random() * lista2.length)];

        const embed = new Discord.MessageEmbed()
            .setDescription(`**${interaction.user} Deu um tapa em ${user}.**`)
            .setImage(`${random1}`)
            .setColor('RANDOM')

        const button = new Discord.MessageActionRow()
            .addComponents(
                new Discord.MessageButton()
                    .setCustomId('tapa')
                    .setLabel('Retribuir')
                    .setStyle('PRIMARY')
                    .setDisabled(false)

            )

        const embed1 = new Discord.MessageEmbed()
            .setDescription(`**${user} Retribuiu o tapa de ${interaction.user}.**`)
            .setColor('RANDOM')
            .setImage(`${random2}`)

        interaction.reply({ embeds: [embed], components: [button] }).then(() => {

            const filter = i => i.customId === 'tapa' && i.user.id === user.id;
            const collector = interaction.channel.createMessageComponentCollector({ filter, max: 1 });

            collector.on('collect', async i => {
                if (i.customId === 'tapa') {
                    i.reply({ embeds: [embed1] })
                }
            });

        })
    }
}
