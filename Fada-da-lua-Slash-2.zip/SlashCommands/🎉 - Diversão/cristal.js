const discord = require('discord.js')
module.exports =  {
    name: "cristal",
    description: "『🎉』Faça a cristal \"bot\" falar!",
    type: "CHAT_INPUT",
    

  run: async (client, interaction, args) => {

     
            
            let respostas = ["Bom Dia","O fanta não me solta do porão, me ajuda 😭","Shiu >:>","Não me marca, tô jogand... digo, tô ocupada"];
        let resposta = respostas[Math.floor(Math.random()*respostas.length)];

        try {

        interaction.channel.createWebhook('Crisταℓ✨', {
            avatar: 'https://cdn.discordapp.com/avatars/423095096897175552/a_c00926cc9d69ccaf550a798e957ce0c2.png?size=1024',

        }).then(web => {
            web.send(`${interaction.user}! **${resposta}**`)
            .then(()=> {web.delete() })
        })

interaction.reply({content: `Fiz a cristal fala!`, ephemeral: true})
          
    } catch (e) { console.log(e); message.reply(`Eu estou sem a permissão de criar webhooks.`) }
        
  }
}