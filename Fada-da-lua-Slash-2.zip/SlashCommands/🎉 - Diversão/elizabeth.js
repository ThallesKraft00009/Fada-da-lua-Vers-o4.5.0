const discord = require('discord.js')
module.exports =  {
    name: "elizabeth",
    description: "『🎉』Faça a elizabeth \"bot\" falar!",
    type: "CHAT_INPUT",
    

  run: async (client, interaction, args) => {

     
            
            let respostas = ["Seu feo, ban","E batata","Quer toma ban? Se quiser fala :D"];
        let resposta = respostas[Math.floor(Math.random()*respostas.length)];

        try {

        interaction.channel.createWebhook(' Elizabeth_OwO ', {
            avatar: 'https://cdn.discordapp.com/avatars/965003786819092500/c8cfd13624892aa92a4255978a102bff.png?size=1024',

        }).then(web => {
            web.send(`${interaction.user}! **${resposta}**`)
            .then(()=> {web.delete() })
        })

interaction.reply({content: `Fiz a Elizabeth_OwO fala!`, ephemeral: true})
          
    } catch (e) { console.log(e); message.reply(`Eu estou sem a permissão de criar webhooks.`) }
        
  }
}