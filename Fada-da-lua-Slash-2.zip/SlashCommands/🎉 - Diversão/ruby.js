const discord = require('discord.js')
module.exports =  {
    name: "ruby",
    description: "『🎉』Faça ruby \"bot\" falar!",
    type: "CHAT_INPUT",
    

  run: async (client, interaction, args) => {

     
            
            let respostas = ["O ouro é meu!","Magaga","Eu estou certo você está errado, fim do debate","Pega maderinha, maderinha pega, pega maderinha meu amor não vai embora","SIIIIIIIIIIM","Tô ocupado, vai chatear outro!","Bruh","Oi guinomio","Se está bem feito fui eu","Se está mal feito foi o Vini","#Potássio","5997.....5998.....5999...QUEM ROUBOU MEU OURO?","Sei lá, foi o Peter","Ba-Ba-Banido!","Eu te mostro o que é Claustrofobia!","Rezamos para Shirley","Como é ver o mundo pelos meus calcachares?","NÃO FUI EU! Foi a Cris","Fonte: Confia","O dia tem 24h então **bom dia**","FanatinhaGameplays5","É meu nome, não o gastes"];
        let resposta = respostas[Math.floor(Math.random()*respostas.length)];

        try {

        interaction.channel.createWebhook('Ruby', {
            avatar: 'https://cdn.discordapp.com/avatars/451712241222549515/af87a3d21d4dbc8d80553ba173961450.png?size=1024',

        }).then(web => {
            web.send(`${interaction.user}! **${resposta}**`)
            .then(()=> {web.delete() })
        })

interaction.reply({content: `Fiz ruby fala!`, ephemeral: true})
          
    } catch (e) { console.log(e); message.reply(`Eu estou sem a permissão de criar webhooks.`) }
        
  }
}