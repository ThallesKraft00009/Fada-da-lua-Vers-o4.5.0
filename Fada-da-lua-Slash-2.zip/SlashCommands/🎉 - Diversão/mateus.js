const discord = require('discord.js')
module.exports =  {
    name: "mateus",
    description: "『🎉』Faça o mateus \"bot\" falar!",
    type: "CHAT_INPUT",
    

  run: async (client, interaction, args) => {

     
            
            let respostas = ["Alguém falou em bolo? 👀","Olá 🖐😈 >:))","Eu vou pegar a marreta 🤨 😈 🔨"];
        let resposta = respostas[Math.floor(Math.random()*respostas.length)];

        try {

        interaction.channel.createWebhook(' ✯ MATEUS ✯', {
            avatar: 'https://cdn.discordapp.com/avatars/731115576197382215/1e0fe262f328c6c1de3d5410e3c317d0.png?size=2048',

        }).then(web => {
            web.send(`${interaction.user}! **${resposta}**`)
            .then(()=> {web.delete() })
        })

interaction.reply({content: `Fiz o mateus fala!`, ephemeral: true})
          
    } catch (e) { console.log(e); message.reply(`Eu estou sem a permissão de criar webhooks.`) }
        
  }
}