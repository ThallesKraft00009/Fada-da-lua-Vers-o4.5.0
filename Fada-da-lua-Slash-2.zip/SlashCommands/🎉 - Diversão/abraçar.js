const Discord = require('discord.js')
module.exports = {
    name: 'abraçar',
    description: '『🎉』Abrace uma pessoa.',
    type: 'CHAT_INPUT',
    options: [
        {
            name: 'membro',
            description: 'Mencione um membro.',
            type: "USER",
            required: true,
        }
    ],
    run: async (client, interaction, args) => {

        let user = interaction.options.getUser('membro')

        let lista1 = [
            'https://imgur.com/RgfGLNk.gif',
            'https://i.imgur.com/r9aU2xv.gif',
            'https://i.imgur.com/wOmoeF8.gif',
            'https://i.imgur.com/nrdYNtL.gif',
            'https://imgur.com/82xVqUg.gif'
        ];

        let lista2 = [
            'https://imgur.com/c3WzMZu.gif',
            'https://imgur.com/BPLqSJC.gif',
            'https://imgur.com/ntqYLGl.gif',
            'https://imgur.com/v47M1S4.gif',
            'https://imgur.com/6qYOUQF.gif'
        ];

        let random1 = lista1[Math.floor(Math.random() * lista1.length)];
        let random2 = lista2[Math.floor(Math.random() * lista2.length)];

        let embed = new Discord.MessageEmbed()
            .setDescription(`**O membro ${interaction.user} abraçou  ${user}.**`)
            .setImage(`${random1}`)
            .setColor('RANDOM')

        let button = new Discord.MessageActionRow()
            .addComponents(
                new Discord.MessageButton()
                    .setCustomId('abraco')
                    .setLabel('Retribuir')
                    .setStyle('PRIMARY')
                    .setDisabled(false)

            )

        let embed1 = new Discord.MessageEmbed()
            .setDescription(`**${user} Retribuiu o abraço de ${interaction.user}.**`)
            .setColor('RANDOM')
            .setImage(`${random2}`);

        interaction.reply({ embeds: [embed], components: [button] }).then(() => {

            const filter = i => i.customId === 'abraco' && i.user.id === user.id;
            const collector = interaction.channel.createMessageComponentCollector({ filter, max: 1 });

            collector.on('collect', async i => {

                if (i.customId === 'abraco') {
                    i.reply({ embeds: [embed1] })
                }
            });
        })

    }
} 
