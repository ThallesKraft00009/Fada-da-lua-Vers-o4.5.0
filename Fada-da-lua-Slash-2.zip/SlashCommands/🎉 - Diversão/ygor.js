const discord = require('discord.js')
module.exports =  {
    name: "ygor",
    description: "『🎉』Faça o ygor \"bot\" falar!",
    type: "CHAT_INPUT",
    

  run: async (client, interaction, args) => {

     
            
            let respostas = ["Sabe o pais que não falta ar? C: || ar-gentina||","Sabe oque um pão francês diz quando queima? ||torreifei|| ||R: torre eifel||","Do jeito que estar, o dólar vai virar **dor**lar","não usem piadas como arma😂"];
        let resposta = respostas[Math.floor(Math.random()*respostas.length)];

        try {

        interaction.channel.createWebhook('Ygor', {
            avatar: 'https://cdn.discordapp.com/avatars/850134703473426493/3f7087dc661c5bc6d0109830718d2e80.png?size=1024',

        }).then(web => {
            web.send(`${interaction.user}! **${resposta}**`)
            .then(()=> {web.delete() })
        })

interaction.reply({content: `Fiz o ygor  fala!`, ephemeral: true})
          
    } catch (e) { console.log(e); message.reply(`Eu estou sem a permissão de criar webhooks.`) }
        
  }
}