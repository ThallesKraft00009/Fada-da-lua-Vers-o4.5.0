const Discord = require('discord.js')
module.exports = {
    name: 'atacar',
    description: '『🎉』Ataque uma pessoa.',
    type: 'CHAT_INPUT',
    options: [
        {
            name: 'membro',
            description: 'Mencione um membro.',
            type: "USER",
            required: true,
        }
    ],
    run: async (client, interaction, args) => {

        let user = interaction.options.getUser('membro')

        var lista1 = [
            'https://loritta.website/assets/img/actions/attack/generic/gif_69.gif','https://loritta.website/assets/img/actions/attack/generic/gif_9.gif','https://loritta.website/assets/img/actions/attack/generic/gif_32.gif','https://loritta.website/assets/img/actions/attack/generic/gif_32.gif','https://loritta.website/assets/img/actions/attack/generic/gif_103.gif','https://loritta.website/assets/img/actions/attack/generic/gif_103.gif','https://loritta.website/assets/img/actions/attack/generic/gif_41.gif','https://loritta.website/assets/img/actions/attack/generic/gif_87.gif','https://loritta.website/assets/img/actions/attack/generic/gif_65.gif','https://loritta.website/assets/img/actions/attack/generic/gif_107.gif;https://loritta.website/assets/img/actions/attack/generic/gif_101.gif','https://loritta.website/assets/img/actions/attack/generic/gif_28.gif','https://loritta.website/assets/img/actions/attack/generic/gif_54.gif','https://loritta.website/assets/img/actions/attack/generic/gif_75.gif','https://loritta.website/assets/img/actions/attack/generic/gif_57.gif','https://loritta.website/assets/img/actions/attack/generic/gif_111.gif'
        ];

        var lista2 = [
       
        'https://loritta.website/assets/img/actions/attack/generic/gif_69.gif','https://loritta.website/assets/img/actions/attack/generic/gif_9.gif','https://loritta.website/assets/img/actions/attack/generic/gif_32.gif','https://loritta.website/assets/img/actions/attack/generic/gif_32.gif','https://loritta.website/assets/img/actions/attack/generic/gif_103.gif','https://loritta.website/assets/img/actions/attack/generic/gif_103.gif','https://loritta.website/assets/img/actions/attack/generic/gif_41.gif','https://loritta.website/assets/img/actions/attack/generic/gif_87.gif','https://loritta.website/assets/img/actions/attack/generic/gif_65.gif','https://loritta.website/assets/img/actions/attack/generic/gif_107.gif;https://loritta.website/assets/img/actions/attack/generic/gif_101.gif','https://loritta.website/assets/img/actions/attack/generic/gif_28.gif','https://loritta.website/assets/img/actions/attack/generic/gif_54.gif','https://loritta.website/assets/img/actions/attack/generic/gif_75.gif','https://loritta.website/assets/img/actions/attack/generic/gif_57.gif','https://loritta.website/assets/img/actions/attack/generic/gif_111.gif'
        ];

        var random1 = lista1[Math.floor(Math.random() * lista1.length)];
        var random2 = lista2[Math.floor(Math.random() * lista2.length)];

        const embed = new Discord.MessageEmbed()
            .setDescription(`**${interaction.user} atacou ${user}!**`)
            .setImage(`${random1}`)
            .setColor('RANDOM')

        const button = new Discord.MessageActionRow()
            .addComponents(
                new Discord.MessageButton()
                    .setCustomId('ataque')
                    .setLabel('Retribuir')
                    .setStyle('PRIMARY')
                    .setDisabled(false)

            )

        const embed1 = new Discord.MessageEmbed()
            .setDescription(`**${user} Retribuiu o ataque de ${interaction.user}.**`)
            .setColor('RANDOM')
            .setImage(`${random2}`)

        interaction.reply({ embeds: [embed], components: [button] }).then(() => {
            const filter = i => i.customId === 'ataque' && i.user.id === user.id;
            const collector = interaction.channel.createMessageComponentCollector({ filter, max: 1 });

            collector.on('collect', async i => {
                if (i.customId === 'ataque') {
                    i.reply({ embeds: [embed1] })
                }
            });
        })
    }
}
