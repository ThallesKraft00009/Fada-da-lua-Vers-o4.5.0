const Discord = require('discord.js');

module.exports =  {
    name: "thalles",
    description: "『🎉』faça uma pergunta ao meu criador",
    type: "CHAT_INPUT",
    options: [
        {
            name: "pergunta",
            type: "STRING",
            description: "Diga a pergunta",
            required: true
            
        }
    
    ],
    
    run: async (client, interaction, args) => {

let msg = interaction.options.getString("pergunta");
      
let avatar = ["https://cdn.discordapp.com/avatars/882913524291088384/a_66cf8b10e69fddd1087328ab4d0acadd.png?size=1024"];
      let nome = ["</ThallesKraft>"]
      let respostas = ["Sim","Não","Provavelmente Sim","Provavelmente Não","Não pergunte para mim.","Nunca nem vi","Obvio que não","Obvio que sim"];

      let resposta = respostas[Math.floor(Math.random()*respostas.length)];

try {
interaction.channel.createWebhook(`${nome}`, {
            avatar: `${avatar}`,
    
}).then(web => {
            web.send(`${interaction.user}! **${resposta}**`)
            .then(()=> {web.delete() })
        })

interaction.reply({content: `Sua pergunta: ${msg}`, ephemeral: true})
          
    } catch (e) { console.log(e); interaction.reply({content: `Eu estou sem a permissão de criar webhooks.`}) }
      
      
      
    }
}